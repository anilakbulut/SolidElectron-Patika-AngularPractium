export interface User{
    user_name?:string,
    user_surname?:string,
    user_email?:string,
    user_password?:string,
    user_address?:string
}