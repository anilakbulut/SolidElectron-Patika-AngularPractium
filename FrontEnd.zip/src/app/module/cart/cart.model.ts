export interface CartDetails{
    product_name?:string,
    product_price?:string,
    user_email?:string
}