export interface Product{
    product_name?:string,
    product_price?:string,
    product_path?:string,
    product_desc?:string,
    product_category?:string
}